println '''
*******************************************************
* You've installed the Spring Security UI plugin  .   *
*                                                     *
* Make sure you have the following plugins installed: *
*    spring-security-core (1.2+)                      *
*    mail (1.0+)                                      *
*    jquery (1.4.4+)                                  *
*    jquery-ui (1.8.7+)                               *
*    famfamfam (1.0+)                                 *
*                                                     *
*******************************************************
'''
